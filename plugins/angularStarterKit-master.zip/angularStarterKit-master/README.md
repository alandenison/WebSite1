# angularStarterKit

BuildFire Plugin developed in Angular 1.x