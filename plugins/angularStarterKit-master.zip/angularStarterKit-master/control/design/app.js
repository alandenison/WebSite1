'use strict';
(function (angular) {
  angular
    .module('angularStarterKitDesign', [])
    .controller('DesignHomeCtrl', function(){
      var DesignHome = this;
      DesignHome.text = "Design Section";
    });
})(window.angular);
